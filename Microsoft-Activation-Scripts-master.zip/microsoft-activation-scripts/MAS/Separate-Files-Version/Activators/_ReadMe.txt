--------------------------------------------------------------------------------------
Activation Type        Supported Product        Activation Period
--------------------------------------------------------------------------------------

HWID                -  Windows 10-11          -  Permanent                           
Ohook               -  Office                 -  Permanent                           
TSforge             -  Windows / ESU / Office -  Permanent                           
KMS38               -  Windows 10-11-Server   -  Till the Year 2038                  
Online KMS          -  Windows / Office       -  180 Days. Lifetime With Renewal Task

--------------------------------------------------------------------------------------

Check the below link for more details:
https://massgrave.dev/chart